import { useState } from "react";
import { MessageCircle, Plus } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { cn } from "@/utils/cn";

const faqs = [
  {
    q: "Is reporting a receipt legal and safe?",
    a: "Yes. Photographing a receipt that was legitimately issued to you is completely lawful. We never ask you to confront anyone or visit anywhere unusual — and every report is anonymised before a human reviewer sees it.",
  },
  {
    q: "How do you know a brand is evading tax?",
    a: "We don’t accuse — we document. Each receipt’s FBR invoice number and QR code are checked, reports from independent citizens are cross-matched, and two human reviewers must confirm the evidence. Only then does a case reach our legal desk. Findings remain allegations until decided by the competent authority.",
  },
  {
    q: "Will my identity be revealed?",
    a: "No. We strip names, phone numbers and device metadata at upload, so we simply can’t hand over what we don’t hold. An account is optional and needs only an email — which you can delete at any time.",
  },
  {
    q: "What happens after I submit a receipt?",
    a: "Automated checks run within seconds. A volunteer reviewer confirms within 48 hours, a second reviewer validates, and our legal desk decides whether to prepare a filing. You’ll get a notification at every milestone.",
  },
  {
    q: "What if the shop is actually compliant?",
    a: "Then you’ll see a green confirmation straight away. We’re not here to punish — we’re here to protect fair players. Businesses that consistently issue valid FBR invoices can earn a public Verified Compliant badge.",
  },
  {
    q: "Are you affiliated with the FBR or any political party?",
    a: "No. Fateh-e-Pakistan is an independent, non-partisan, non-profit initiative funded by citizen memberships and grants. We publish our accounts every year.",
  },
  {
    q: "Which receipts qualify?",
    a: "Any bill showing sales tax being charged — restaurants, retail chains, electronics, clinics, salons, and printed invoices for online orders. Urdu and English receipts both work.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" aria-labelledby="faq-title" className="relative py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <SectionHeading
            id="faq-title"
            align="left"
            eyebrow="FAQ"
            title={
              <>
                Questions, <Accent>answered</Accent>
              </>
            }
            description="Everything you need to know before you scan your first receipt."
          />
          <Reveal delay={260}>
            <div className="mt-8 flex items-center gap-4 rounded-3xl border border-ink-200/70 bg-white p-5 shadow-card">
              <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200">
                <MessageCircle className="size-5" aria-hidden />
              </span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-ink-950">Still have questions?</p>
                <p className="text-sm text-ink-500">Our volunteers reply within a day.</p>
              </div>
              <Button href="mailto:hello@fateh-e-pakistan.org" variant="secondary" size="md">
                Ask us
              </Button>
            </div>
          </Reveal>
        </div>

        <div className="space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={f.q} delay={i * 60}>
                <div
                  className={cn(
                    "overflow-hidden rounded-3xl border bg-white transition-all duration-500 ease-[var(--ease-out-expo)]",
                    isOpen ? "border-brand-200 shadow-lift" : "border-ink-200/70 shadow-card hover:border-ink-300"
                  )}
                >
                  <h3>
                    <button
                      type="button"
                      id={`faq-btn-${i}`}
                      aria-expanded={isOpen}
                      aria-controls={`faq-panel-${i}`}
                      onClick={() => setOpen(isOpen ? null : i)}
                      className="flex min-h-[4.25rem] w-full items-center justify-between gap-4 px-6 py-4 text-left sm:px-7"
                    >
                      <span className="text-base font-semibold tracking-tight text-ink-950 sm:text-[1.05rem]">{f.q}</span>
                      <span
                        aria-hidden
                        className={cn(
                          "grid size-9 shrink-0 place-items-center rounded-full transition-all duration-500 ease-[var(--ease-out-expo)]",
                          isOpen ? "rotate-45 bg-brand-500 text-white" : "bg-ink-100 text-ink-700"
                        )}
                      >
                        <Plus className="size-4" />
                      </span>
                    </button>
                  </h3>
                  <div
                    id={`faq-panel-${i}`}
                    role="region"
                    aria-labelledby={`faq-btn-${i}`}
                    className={cn(
                      "grid transition-[grid-template-rows,opacity] duration-500 ease-[var(--ease-out-expo)]",
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="px-6 pb-6 pr-14 text-[0.95rem] leading-relaxed text-ink-600 sm:px-7">{f.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
