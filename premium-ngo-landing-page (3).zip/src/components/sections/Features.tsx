import type { ReactNode } from "react";
import { BadgeCheck, EyeOff, Fingerprint, Map as MapIcon, Scale, ScanLine, TrendingUp, type LucideIcon } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { useInView } from "@/hooks/useInView";
import { cn } from "@/utils/cn";

function IconTile({ icon: Icon, tone = "brand" }: { icon: LucideIcon; tone?: "brand" | "gold" | "ink" }) {
  return (
    <span
      className={cn(
        "grid size-12 place-items-center rounded-2xl ring-1 ring-inset transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover/card:-rotate-6 group-hover/card:scale-110",
        tone === "brand" && "bg-brand-50 text-brand-700 ring-brand-200",
        tone === "gold" && "bg-gold-300/25 text-gold-500 ring-gold-300/60",
        tone === "ink" && "bg-ink-100 text-ink-800 ring-ink-200"
      )}
    >
      <Icon className="size-5.5" aria-hidden />
    </span>
  );
}

function FeatureCard({
  icon,
  tone,
  title,
  children,
  visual,
  className,
  delay = 0,
}: {
  icon: LucideIcon;
  tone?: "brand" | "gold" | "ink";
  title: string;
  children: ReactNode;
  visual?: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <Reveal delay={delay} className={className}>
      <SpotlightCard className="group/card flex h-full flex-col overflow-hidden p-7 sm:p-8">
        <IconTile icon={icon} tone={tone} />
        <h3 className="mt-6 text-xl font-semibold">{title}</h3>
        <p className="mt-2.5 max-w-md text-[0.95rem] leading-relaxed text-ink-600">{children}</p>
        {visual && <div className="mt-auto pt-7">{visual}</div>}
      </SpotlightCard>
    </Reveal>
  );
}

/* ---------- Visual: OCR read-out ---------- */
function OcrVisual() {
  const rows = [
    { k: "Shop", v: "Sample Kitchen & Co.", ok: true },
    { k: "NTN", v: "•••••••-3", ok: true },
    { k: "GST charged", v: "Rs 1,800 (18%)", ok: true },
    { k: "FBR invoice no.", v: "Not found", ok: false },
  ];
  return (
    <div className="relative overflow-hidden rounded-2xl border border-ink-200/70 bg-ink-50/70 p-4">
      <span
        aria-hidden
        className="pointer-events-none absolute inset-x-0 h-12 animate-scan bg-gradient-to-b from-transparent via-brand-400/15 to-transparent"
      />
      <ul className="relative space-y-2.5 font-mono text-[0.78rem]">
        {rows.map((r) => (
          <li key={r.k} className="flex items-center justify-between gap-3">
            <span className="text-ink-500">{r.k}</span>
            <span className="flex items-center gap-2">
              <span className={cn("font-medium", r.ok ? "text-ink-900" : "text-rose-600")}>{r.v}</span>
              <span
                aria-hidden
                className={cn(
                  "grid size-4.5 place-items-center rounded-full text-[0.6rem] font-bold text-white",
                  r.ok ? "bg-brand-500" : "bg-rose-500"
                )}
              >
                {r.ok ? "✓" : "✕"}
              </span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ---------- Visual: risk bars ---------- */
function RiskBars() {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.4 });
  const data = [
    { label: "Dining & cafés", v: 78, c: "from-rose-400 to-rose-500" },
    { label: "Electronics", v: 64, c: "from-gold-400 to-gold-500" },
    { label: "Apparel", v: 52, c: "from-gold-300 to-gold-400" },
    { label: "Clinics & labs", v: 31, c: "from-brand-400 to-brand-500" },
  ];
  return (
    <div ref={ref} className="space-y-3" role="img" aria-label="Sample chart of risk score by sector">
      {data.map((d, i) => (
        <div key={d.label} aria-hidden>
          <div className="mb-1 flex justify-between text-xs">
            <span className="font-medium text-ink-700">{d.label}</span>
            <span className="font-mono text-ink-500">{d.v}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-ink-100">
            <div
              className={cn("h-full rounded-full bg-gradient-to-r transition-[width] duration-[1400ms] ease-[var(--ease-out-expo)]", d.c)}
              style={{ width: inView ? `${d.v}%` : "0%", transitionDelay: `${i * 140}ms` }}
            />
          </div>
        </div>
      ))}
      <p className="pt-1 text-[0.7rem] text-ink-400">Sample data · risk score out of 100</p>
    </div>
  );
}

/* ---------- Visual: verified badge ---------- */
function BadgeVisual() {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-brand-200 bg-gradient-to-br from-brand-50 to-white p-4">
      <span className="relative grid size-11 place-items-center rounded-full bg-brand-500 text-white shadow-lg shadow-brand-500/30">
        <span aria-hidden className="absolute inset-0 animate-pulse-ring rounded-full bg-brand-500/50" />
        <BadgeCheck className="relative size-6" aria-hidden />
      </span>
      <div>
        <p className="text-sm font-semibold text-ink-950">Verified Compliant</p>
        <p className="text-xs text-ink-500">Valid FBR invoices · 12 months</p>
      </div>
    </div>
  );
}

/* ---------- Visual: hotspot map ---------- */
const cities = [
  { name: "Peshawar", x: 44, y: 14, s: 2 },
  { name: "Islamabad", x: 62, y: 22, s: 3 },
  { name: "Lahore", x: 76, y: 38, s: 4 },
  { name: "Quetta", x: 22, y: 46, s: 2 },
  { name: "Multan", x: 58, y: 54, s: 3 },
  { name: "Karachi", x: 36, y: 84, s: 4 },
];

function MapVisual() {
  return (
    <div className="relative h-52 overflow-hidden rounded-2xl border border-ink-200/70 bg-gradient-to-br from-ink-950 to-brand-950 sm:h-56">
      <div aria-hidden className="bg-dots mask-fade-radial absolute inset-0 opacity-30 invert" />
      {cities.map((c, i) => (
        <div
          key={c.name}
          className="absolute -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${c.x}%`, top: `${c.y}%` }}
        >
          <span className="relative flex items-center justify-center">
            <span
              aria-hidden
              className="absolute animate-pulse-ring rounded-full bg-rose-400/60"
              style={{ width: 10 + c.s * 5, height: 10 + c.s * 5, animationDelay: `${i * 380}ms` }}
            />
            <span className="relative size-2.5 rounded-full bg-rose-400 ring-2 ring-white/30" />
          </span>
          <span className="absolute left-4 top-1/2 -translate-y-1/2 whitespace-nowrap rounded-full bg-white/10 px-2 py-0.5 text-[0.65rem] font-medium text-white/80 backdrop-blur">
            {c.name}
          </span>
        </div>
      ))}
      <div className="absolute bottom-3 left-3 rounded-full bg-white/10 px-2.5 py-1 text-[0.65rem] font-medium text-white/70 backdrop-blur">
        Sample hotspots · last 30 days
      </div>
    </div>
  );
}

export function Features() {
  return (
    <section id="features" aria-labelledby="features-title" className="relative py-20 sm:py-28">
      <div aria-hidden className="absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-ink-200 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="features-title"
          eyebrow="Platform"
          title={
            <>
              Built to make tax evasion <Accent>impossible to ignore</Accent>
            </>
          }
          description="A calm, powerful toolkit that takes a citizen’s receipt and turns it into evidence that authorities can act on."
        />

        <div className="mt-14 grid gap-5 sm:mt-20 lg:grid-cols-12">
          <FeatureCard
            className="lg:col-span-7"
            icon={ScanLine}
            title="Instant receipt verification"
            visual={<OcrVisual />}
          >
            Point your camera at any bill. We read the shop, NTN, GST line and FBR invoice number in seconds — and tell you
            immediately if something doesn’t add up.
          </FeatureCard>

          <FeatureCard
            className="lg:col-span-5"
            icon={TrendingUp}
            tone="gold"
            delay={100}
            title="Brand Risk Index"
            visual={<RiskBars />}
          >
            Aggregated, anonymised signals show where non-compliance clusters — by sector, city and outlet.
          </FeatureCard>

          <FeatureCard className="lg:col-span-4" icon={Fingerprint} tone="ink" title="Tamper-proof evidence vault">
            Every photo is hash-sealed, time-stamped and geo-tagged the moment you capture it — so your evidence stands up
            when it matters.
          </FeatureCard>

          <FeatureCard className="lg:col-span-4" icon={EyeOff} tone="ink" delay={100} title="Anonymous by design">
            No name, no phone number, no problem. Personal metadata is stripped before anyone on our team ever sees a
            report.
          </FeatureCard>

          <FeatureCard className="lg:col-span-4" icon={Scale} tone="ink" delay={200} title="Pro-bono legal desk">
            Volunteer advocates and chartered accountants review each case and prepare filings that authorities can act
            on.
          </FeatureCard>

          <FeatureCard
            className="lg:col-span-5"
            icon={BadgeCheck}
            delay={0}
            title="Recognising honest brands"
            visual={<BadgeVisual />}
          >
            Not every business is a villain. Brands that consistently issue valid FBR invoices earn a public Verified badge
            — because compliance deserves credit.
          </FeatureCard>

          <FeatureCard
            className="lg:col-span-7"
            icon={MapIcon}
            tone="gold"
            delay={100}
            title="Live evasion map"
            visual={<MapVisual />}
          >
            Watch patterns emerge city by city. Journalists, researchers and policymakers get open, anonymised insights.
          </FeatureCard>
        </div>
      </div>
    </section>
  );
}
