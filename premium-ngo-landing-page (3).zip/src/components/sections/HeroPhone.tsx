import { useEffect, useState } from "react";
import { AlertTriangle, Check, ChevronLeft, FileWarning, Loader2, RotateCcw, ScanLine, X, Zap } from "lucide-react";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { cn } from "@/utils/cn";

/**
 * Animated phone mock-up that loops through: scanning → verifying → flagged.
 * Purely illustrative — hidden from assistive tech, with a text alternative.
 */
export function HeroPhone() {
  const reduced = useReducedMotion();
  const [step, setStep] = useState(0);
  const [cycle, setCycle] = useState(0);

  useEffect(() => {
    if (reduced) {
      setStep(2);
      return;
    }
    const timers: number[] = [];
    const run = () => {
      setStep(0);
      timers.push(window.setTimeout(() => setStep(1), 2800));
      timers.push(window.setTimeout(() => setStep(2), 4800));
      timers.push(window.setTimeout(run, 12000));
    };
    run();
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [reduced, cycle]);

  const flagged = step === 2;

  return (
    <div className="flex flex-col items-center">
      <div
        role="img"
        aria-label="Animated demo of the Fateh-e-Pakistan app: a shop receipt is scanned, its FBR invoice number is checked, and the receipt is flagged because 18% sales tax was charged but no FBR invoice number or QR code was found."
        className="relative"
      >
        {/* Ambient glow behind phone */}
        <div aria-hidden className="absolute -inset-10 -z-10 rounded-full bg-brand-400/30 blur-3xl" />

        <div
          aria-hidden
          className="relative aspect-[9/18.4] w-[17.5rem] rounded-[2.7rem] bg-ink-950 p-[9px] shadow-[0_60px_100px_-30px_rgb(6_38_27/0.6),inset_0_0_0_1px_rgb(255_255_255/0.1)] sm:w-[19rem]"
        >
          {/* hardware buttons */}
          <span className="absolute -left-[3px] top-24 h-8 w-[3px] rounded-l bg-ink-800" />
          <span className="absolute -left-[3px] top-36 h-14 w-[3px] rounded-l bg-ink-800" />
          <span className="absolute -right-[3px] top-32 h-20 w-[3px] rounded-r bg-ink-800" />

          <div className="relative h-full overflow-hidden rounded-[2.1rem] bg-gradient-to-b from-ink-800 via-ink-900 to-ink-950">
            {/* camera table texture */}
            <div className="absolute inset-0 bg-dots opacity-10 invert" />
            <div className="absolute -top-16 left-1/2 size-64 -translate-x-1/2 rounded-full bg-brand-500/20 blur-3xl" />

            {/* dynamic island */}
            <div className="absolute left-1/2 top-2.5 z-30 h-[1.15rem] w-20 -translate-x-1/2 rounded-full bg-black" />

            {/* app header */}
            <div className="relative z-20 flex items-center justify-between px-4 pt-9 text-white">
              <span className="grid size-7 place-items-center rounded-full bg-white/10 backdrop-blur">
                <ChevronLeft className="size-4" />
              </span>
              <span className="text-[11px] font-semibold tracking-wide">Scan receipt</span>
              <span className="grid size-7 place-items-center rounded-full bg-white/10 backdrop-blur">
                <Zap className="size-3.5 text-gold-300" />
              </span>
            </div>

            {/* viewfinder + receipt */}
            <div className="absolute inset-x-0 top-[4.4rem] z-10 flex justify-center">
              <div
                className={cn(
                  "relative w-[78%] origin-top drop-shadow-[0_24px_28px_rgb(0_0_0/0.45)] transition-all duration-1000 ease-[var(--ease-out-expo)]",
                  flagged ? "-translate-y-1 scale-[0.9]" : "translate-y-0 scale-100"
                )}
              >
                {/* Corner brackets */}
                {[
                  "-left-2 -top-2 border-l-2 border-t-2 rounded-tl-lg",
                  "-right-2 -top-2 border-r-2 border-t-2 rounded-tr-lg",
                  "-bottom-2 -left-2 border-b-2 border-l-2 rounded-bl-lg",
                  "-bottom-2 -right-2 border-b-2 border-r-2 rounded-br-lg",
                ].map((c) => (
                  <span
                    key={c}
                    className={cn(
                      "absolute z-20 size-5 transition-colors duration-500",
                      flagged ? "border-rose-400" : "border-brand-300",
                      c
                    )}
                  />
                ))}

                <div className="receipt-edge relative -rotate-[1.5deg] bg-[#fbfaf5] px-3.5 pb-5 pt-3.5 font-mono text-[8.5px] leading-[1.55] text-ink-800 sm:text-[9px]">
                  <p className="text-center text-[10px] font-medium tracking-[0.14em] text-ink-950">SAMPLE KITCHEN &amp; CO.</p>
                  <p className="text-center text-ink-500">Gulberg III · Lahore</p>
                  <p className="my-1.5 border-t border-dashed border-ink-300" />
                  {[
                    ["Family Karahi ×1", "4,800"],
                    ["BBQ Platter ×1", "3,600"],
                    ["Naan ×6", "600"],
                    ["Cold drinks ×4", "1,000"],
                  ].map(([a, b]) => (
                    <p key={a} className="flex justify-between">
                      <span>{a}</span>
                      <span>{b}</span>
                    </p>
                  ))}
                  <p className="my-1.5 border-t border-dashed border-ink-300" />
                  <p className="flex justify-between">
                    <span>Subtotal</span>
                    <span>10,000</span>
                  </p>
                  <p
                    className={cn(
                      "-mx-1 flex justify-between rounded px-1 transition-colors duration-700",
                      flagged ? "bg-gold-300/70" : step === 1 ? "bg-brand-200/70" : "bg-transparent"
                    )}
                  >
                    <span>GST 18%</span>
                    <span className="font-medium">1,800</span>
                  </p>
                  <p className="flex justify-between font-medium text-ink-950">
                    <span>TOTAL</span>
                    <span>11,800</span>
                  </p>
                  <p className="my-1.5 border-t border-dashed border-ink-300" />
                  <p
                    className={cn(
                      "-mx-1 flex justify-between rounded px-1 transition-colors duration-700",
                      flagged ? "bg-rose-200/80 text-rose-800" : step === 1 ? "bg-brand-200/70" : "bg-transparent"
                    )}
                  >
                    <span>FBR INV #</span>
                    <span>{flagged ? "— none —" : "· · · · ·"}</span>
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    <div
                      className={cn(
                        "grid size-10 place-items-center rounded border border-dashed text-[7px] transition-colors duration-700",
                        flagged ? "border-rose-400 text-rose-600" : "border-ink-300 text-ink-400"
                      )}
                    >
                      {flagged ? "NO QR" : "QR?"}
                    </div>
                    <p className="text-[7.5px] text-ink-500">Thank you for dining with us!</p>
                  </div>

                  {/* scan line */}
                  {step < 2 && (
                    <span
                      className="absolute inset-x-0 z-20 h-10 animate-scan bg-gradient-to-b from-transparent via-brand-400/30 to-transparent"
                      style={{ animationDuration: step === 1 ? "1.2s" : undefined }}
                    >
                      <span className="absolute inset-x-0 bottom-0 h-[2px] bg-brand-400 shadow-[0_0_14px_3px_rgb(72_185_133/0.8)]" />
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Result sheet */}
            <div
              className="absolute inset-x-2 bottom-2 z-30 rounded-[1.6rem] bg-white p-3.5 shadow-[0_-20px_50px_-10px_rgb(0_0_0/0.5)]"
            >
              <div className="mx-auto mb-2.5 h-1 w-8 rounded-full bg-ink-200" />

              {step === 0 && (
                <div key="s0" className="animate-rise" style={{ animationDuration: "0.5s" }}>
                  <div className="flex items-center gap-2 text-[11px] font-semibold text-ink-900">
                    <ScanLine className="size-4 text-brand-600" /> Reading receipt…
                  </div>
                  <div className="mt-3 space-y-2">
                    {[78, 56, 68].map((w, i) => (
                      <div key={w} className="h-2.5 overflow-hidden rounded-full bg-ink-100">
                        <div
                          className="h-full animate-pulse rounded-full bg-brand-200"
                          style={{ width: `${w}%`, animationDelay: `${i * 200}ms` }}
                        />
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 text-[10px] text-ink-500">Hold steady — extracting shop, tax and invoice details.</p>
                </div>
              )}

              {step === 1 && (
                <div key="s1" className="animate-rise" style={{ animationDuration: "0.5s" }}>
                  <div className="flex items-center gap-2 text-[11px] font-semibold text-ink-900">
                    <Loader2 className="size-4 animate-spin text-brand-600" /> Verifying with FBR records…
                  </div>
                  <ul className="mt-3 space-y-2 text-[10.5px] text-ink-700">
                    {["Shop & NTN detected", "GST line found — 18%", "Looking up invoice number"].map((t, i) => (
                      <li key={t} className="flex items-center gap-2">
                        {i < 2 ? (
                          <Check className="size-3.5 text-brand-600" />
                        ) : (
                          <Loader2 className="size-3.5 animate-spin text-ink-400" />
                        )}
                        <span>{t}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {flagged && (
                <div key="s2" className="animate-rise" style={{ animationDuration: "0.6s" }}>
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-50 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-rose-700 ring-1 ring-inset ring-rose-200">
                      <AlertTriangle className="size-3" /> Flagged
                    </span>
                    <span className="text-[10px] font-medium text-ink-500">
                      Evidence strength <b className="text-ink-950">92%</b>
                    </span>
                  </div>
                  <ul className="mt-2.5 divide-y divide-ink-100 text-[10.5px]">
                    <li className="flex items-center justify-between py-1.5">
                      <span className="flex items-center gap-2 text-ink-700">
                        <span className="grid size-4 place-items-center rounded-full bg-gold-300/60 text-gold-500">
                          <Check className="size-2.5" strokeWidth={3} />
                        </span>
                        GST 18% charged
                      </span>
                      <b className="text-ink-950">Rs 1,800</b>
                    </li>
                    <li className="flex items-center justify-between py-1.5">
                      <span className="flex items-center gap-2 text-ink-700">
                        <span className="grid size-4 place-items-center rounded-full bg-rose-100 text-rose-600">
                          <X className="size-2.5" strokeWidth={3} />
                        </span>
                        FBR invoice number
                      </span>
                      <b className="text-rose-600">Not found</b>
                    </li>
                    <li className="flex items-center justify-between py-1.5">
                      <span className="flex items-center gap-2 text-ink-700">
                        <span className="grid size-4 place-items-center rounded-full bg-rose-100 text-rose-600">
                          <X className="size-2.5" strokeWidth={3} />
                        </span>
                        Verification QR
                      </span>
                      <b className="text-rose-600">Missing</b>
                    </li>
                  </ul>
                  <div className="mt-2 flex h-9 items-center justify-center gap-1.5 rounded-full bg-gradient-to-b from-brand-500 to-brand-700 text-[11px] font-semibold text-white">
                    <FileWarning className="size-3.5" /> Add to case file
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={() => setCycle((c) => c + 1)}
        className="group mt-6 inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold text-ink-600 ring-1 ring-inset ring-ink-200 transition hover:bg-white hover:text-ink-950 hover:ring-ink-300 active:scale-95"
      >
        <RotateCcw className="size-3.5 transition-transform duration-500 group-hover:-rotate-180" aria-hidden />
        Replay demo
      </button>
    </div>
  );
}
