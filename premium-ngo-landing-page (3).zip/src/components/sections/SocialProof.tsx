import { Building2, Gavel, HeartHandshake, Landmark, Newspaper, Scale, Users, Fingerprint } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { useInView } from "@/hooks/useInView";
import { useCountUp } from "@/hooks/useCountUp";

const partners = [
  { name: "Transparency Forum PK", icon: Landmark },
  { name: "Consumer Rights Collective", icon: HeartHandshake },
  { name: "Lahore CA Circle", icon: Scale },
  { name: "Karachi Legal Aid Society", icon: Gavel },
  { name: "Digital Rights Lab", icon: Fingerprint },
  { name: "Youth for Accountability", icon: Users },
  { name: "Peshawar Civic Trust", icon: Building2 },
  { name: "The Free Press Network", icon: Newspaper },
];

const stats = [
  { value: 48200, prefix: "", suffix: "+", label: "Receipts scanned", note: "and counting, every single day" },
  { value: 3915, prefix: "", suffix: "", label: "Cases documented", note: "each verified by two reviewers" },
  { value: 412, prefix: "Rs ", suffix: "M+", label: "Tax at risk flagged", note: "estimated from verified cases" },
  { value: 1940, prefix: "", suffix: "", label: "Active volunteers", note: "across 38 cities nationwide" },
];

function Stat({ value, prefix, suffix, label, note, delay }: (typeof stats)[number] & { delay: number }) {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.4 });
  const n = useCountUp(value, inView);

  return (
    <div ref={ref} className="group bg-white/90 p-6 transition-colors duration-500 hover:bg-white sm:p-8">
      <Reveal delay={delay}>
        <p className="text-4xl font-semibold tracking-tight text-ink-950 tabular-nums sm:text-5xl">
          <span className="text-gradient">
            {prefix}
            {Math.round(n).toLocaleString("en-US")}
            {suffix}
          </span>
        </p>
        <p className="mt-2 text-sm font-semibold text-ink-900">{label}</p>
        <p className="mt-1 text-[0.8rem] leading-snug text-ink-500">{note}</p>
      </Reveal>
    </div>
  );
}

export function SocialProof() {
  const loop = [...partners, ...partners];

  return (
    <section aria-labelledby="proof-title" className="relative py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal>
          <p id="proof-title" className="text-center text-sm font-medium text-ink-500">
            Trusted by civic groups, legal clinics &amp; honest businesses across Pakistan
          </p>
        </Reveal>
      </div>

      {/* Partner marquee */}
      <Reveal className="mt-8">
        <div className="group mask-fade-x overflow-hidden" aria-label="Partner organisations" role="group">
          <ul className="flex w-max animate-marquee gap-4 py-2 group-hover:[animation-play-state:paused]">
            {loop.map((p, i) => (
              <li
                key={p.name + i}
                aria-hidden={i >= partners.length}
                className="flex items-center gap-2.5 rounded-full border border-ink-200/70 bg-white/70 px-5 py-3 text-sm font-semibold text-ink-600 backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-brand-300 hover:bg-white hover:text-ink-950"
              >
                <p.icon className="size-4.5 text-brand-600" aria-hidden />
                <span className="whitespace-nowrap">{p.name}</span>
              </li>
            ))}
          </ul>
        </div>
      </Reveal>

      {/* Stats */}
      <div className="mx-auto mt-12 max-w-7xl px-5 sm:mt-16 sm:px-8">
        <Reveal dir="scale">
          <dl className="sr-only">
            {stats.map((s) => (
              <div key={s.label}>
                <dt>{s.label}</dt>
                <dd>
                  {s.prefix}
                  {s.value.toLocaleString("en-US")}
                  {s.suffix}
                </dd>
              </div>
            ))}
          </dl>
          <div
            aria-hidden
            className="grid grid-cols-2 gap-px overflow-hidden rounded-[2rem] border border-ink-200/70 bg-ink-200/60 shadow-card lg:grid-cols-4"
          >
            {stats.map((s, i) => (
              <Stat key={s.label} {...s} delay={i * 90} />
            ))}
          </div>
        </Reveal>
        <p className="mt-4 text-center text-xs text-ink-400">Figures shown are illustrative sample data for this preview.</p>
      </div>
    </section>
  );
}
