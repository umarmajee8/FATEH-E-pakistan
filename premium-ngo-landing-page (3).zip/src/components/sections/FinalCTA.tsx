import { useId, useState, type FormEvent } from "react";
import { ArrowRight, CheckCircle2, Loader2, Lock, ShieldCheck, Sparkles } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent } from "@/components/ui/SectionHeading";
import { cn } from "@/utils/cn";

type Status = "idle" | "loading" | "success";

export function FinalCTA() {
  const emailId = useId();
  const errId = useId();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [status, setStatus] = useState<Status>("idle");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      setError("Please enter a valid email address, like name@example.com.");
      return;
    }
    setError("");
    setStatus("loading");
    // Simulated request — wire up to your mailing-list provider.
    window.setTimeout(() => setStatus("success"), 1100);
  };

  return (
    <section id="join" aria-labelledby="join-title" className="px-3 py-10 sm:px-6 sm:py-16">
      <Reveal dir="scale">
        <div className="relative isolate mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-gradient-to-br from-brand-800 via-brand-900 to-ink-950 px-6 py-16 text-center shadow-[0_60px_120px_-40px_rgb(6_38_27/0.8)] sm:rounded-[3rem] sm:px-12 sm:py-24">
          {/* Backdrop */}
          <div aria-hidden className="absolute inset-0 -z-10">
            <div className="bg-grid-light mask-fade-radial absolute inset-0" />
            <div className="absolute -left-20 -top-24 size-96 animate-drift rounded-full bg-brand-400/30 blur-3xl" />
            <div className="absolute -bottom-32 -right-20 size-[26rem] animate-drift-slow rounded-full bg-gold-400/25 blur-3xl" />
            {/* Rotating ring */}
            <div className="absolute left-1/2 top-1/2 size-[46rem] -translate-x-1/2 -translate-y-1/2 animate-spin-slow rounded-full border border-dashed border-white/10" />
            <div className="absolute left-1/2 top-1/2 size-[32rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/5" />
          </div>

          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-brand-100 ring-1 ring-inset ring-white/15 backdrop-blur">
            <Sparkles className="size-3.5 text-gold-300" aria-hidden /> Join the movement
          </span>

          <h2
            id="join-title"
            className="mx-auto mt-6 max-w-3xl text-balance text-[2.1rem] font-semibold leading-[1.06] !text-white sm:text-5xl lg:text-6xl"
          >
            Your next receipt could be the <Accent light>evidence that counts.</Accent>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-pretty text-base leading-relaxed text-white/70 sm:text-lg">
            Get early access to the app, monthly impact updates and simple ways to help — free for every citizen, forever.
          </p>

          <div className="mx-auto mt-10 max-w-lg">
            {status === "success" ? (
              <div
                role="status"
                className="animate-rise flex flex-col items-center gap-3 rounded-3xl bg-white/10 p-8 ring-1 ring-inset ring-white/20 backdrop-blur"
              >
                <span className="grid size-14 place-items-center rounded-full bg-brand-400 text-white shadow-lg shadow-brand-500/40">
                  <CheckCircle2 className="size-7" aria-hidden />
                </span>
                <p className="text-xl font-semibold text-white">Shukriya — you’re on the list!</p>
                <p className="text-sm text-white/70">
                  We’ve sent a confirmation to <b className="text-white">{email}</b>. Welcome to the watch.
                </p>
              </div>
            ) : (
              <form onSubmit={onSubmit} noValidate aria-describedby={error ? errId : undefined}>
                <div
                  className={cn(
                    "flex flex-col gap-2 rounded-[1.75rem] bg-white/10 p-2 ring-1 ring-inset backdrop-blur transition-all duration-300 focus-within:bg-white/15 focus-within:ring-2 focus-within:ring-brand-300 sm:flex-row sm:rounded-full",
                    error ? "ring-rose-300" : "ring-white/20"
                  )}
                >
                  <label htmlFor={emailId} className="sr-only">
                    Email address
                  </label>
                  <input
                    id={emailId}
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (error) setError("");
                    }}
                    aria-invalid={!!error}
                    aria-describedby={error ? errId : undefined}
                    className="h-12 min-w-0 flex-1 rounded-full bg-transparent px-5 text-base text-white outline-none placeholder:text-white/40"
                  />
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    className="group relative inline-flex h-12 items-center justify-center gap-2 overflow-hidden rounded-full bg-white px-6 text-sm font-semibold text-brand-950 transition-all duration-300 hover:bg-brand-50 hover:shadow-[0_10px_40px_-10px_rgb(255_255_255/0.5)] active:scale-[0.97] disabled:opacity-80"
                  >
                    {status === "loading" ? (
                      <>
                        <Loader2 className="size-4 animate-spin" aria-hidden /> Joining…
                      </>
                    ) : (
                      <>
                        Join the movement
                        <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
                      </>
                    )}
                  </button>
                </div>
                <p id={errId} role="alert" className={cn("mt-3 text-sm text-rose-200", !error && "sr-only")}>
                  {error}
                </p>
              </form>
            )}
          </div>

          <ul className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[0.8rem] font-medium text-white/60">
            <li className="inline-flex items-center gap-1.5">
              <Lock className="size-3.5 text-brand-300" aria-hidden /> Your email is never shared
            </li>
            <li className="inline-flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 text-brand-300" aria-hidden /> Free forever for citizens
            </li>
          </ul>
        </div>
      </Reveal>
    </section>
  );
}
