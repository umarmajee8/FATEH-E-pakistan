import { Quote, Star } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { cn } from "@/utils/cn";

const testimonials = [
  {
    quote:
      "I photographed a bill after dinner, tapped once, and forgot about it. Three weeks later I got a message that the outlet’s case had been filed. I’ve never felt more like a citizen.",
    name: "Ayesha R.",
    role: "Volunteer reporter · Lahore",
    grad: "from-brand-400 to-brand-700",
    featured: true,
  },
  {
    quote:
      "As a chartered accountant I’ve been waiting for evidence this clean. The audit trail is exactly what we need to file with confidence.",
    name: "Adv. Imran Q.",
    role: "Legal desk · Karachi",
    grad: "from-gold-300 to-gold-500",
  },
  {
    quote:
      "We pay every rupee of tax and still lose customers to shops that don’t. Fateh-e-Pakistan finally gives us a fair fight.",
    name: "Hamza S.",
    role: "Bakery owner · Faisalabad",
    grad: "from-ink-500 to-ink-800",
  },
  {
    quote:
      "Our newsroom uses the anonymised risk data for investigations. Rigorous, careful and refreshingly non-political.",
    name: "Sana K.",
    role: "Investigative journalist · Islamabad",
    grad: "from-rose-300 to-rose-500",
  },
];

function Stars() {
  return (
    <div className="flex gap-0.5" role="img" aria-label="Rated 5 out of 5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className="size-4 fill-gold-400 text-gold-400" aria-hidden />
      ))}
    </div>
  );
}

export function Testimonials() {
  return (
    <section id="voices" aria-labelledby="voices-title" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="voices-title"
          eyebrow="Voices"
          title={
            <>
              Ordinary people. <Accent>Extraordinary</Accent> impact.
            </>
          }
          description="Shoppers, shop owners, lawyers and journalists — all on the same side of the counter."
        />

        <div className="mt-14 grid gap-5 sm:mt-20 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={(i % 3) * 110} className={cn(t.featured && "lg:col-span-2")}>
              <figure
                className={cn(
                  "group relative flex h-full flex-col justify-between overflow-hidden rounded-3xl p-7 transition-all duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1.5 sm:p-9",
                  t.featured
                    ? "bg-gradient-to-br from-brand-800 via-brand-900 to-ink-950 text-white shadow-[0_40px_80px_-30px_rgb(6_38_27/0.7)]"
                    : "border border-ink-200/70 bg-white shadow-card hover:shadow-lift"
                )}
              >
                {t.featured && (
                  <>
                    <div aria-hidden className="absolute -right-16 -top-16 size-64 rounded-full bg-brand-400/25 blur-3xl transition-transform duration-1000 group-hover:scale-125" />
                    <div aria-hidden className="bg-grid-light mask-fade-radial absolute inset-0 opacity-60" />
                  </>
                )}
                <div className="relative">
                  <div className="flex items-center justify-between">
                    <Stars />
                    <Quote
                      className={cn("size-8 rotate-180", t.featured ? "text-brand-300/40" : "text-brand-200")}
                      aria-hidden
                    />
                  </div>
                  <blockquote
                    className={cn(
                      "mt-6 text-pretty leading-relaxed",
                      t.featured
                        ? "font-serif text-2xl text-white sm:text-[1.9rem] sm:leading-[1.3]"
                        : "text-[0.98rem] text-ink-700"
                    )}
                  >
                    “{t.quote}”
                  </blockquote>
                </div>
                <figcaption className="relative mt-8 flex items-center gap-3.5">
                  <span
                    aria-hidden
                    className={cn(
                      "grid size-11 place-items-center rounded-full bg-gradient-to-br text-sm font-bold text-white ring-2",
                      t.grad,
                      t.featured ? "ring-white/20" : "ring-white"
                    )}
                  >
                    {t.name
                      .replace(/^(Adv\.|Prof\.)\s/, "")
                      .split(" ")
                      .map((w) => w[0])
                      .join("")}
                  </span>
                  <span>
                    <span className={cn("block text-sm font-semibold", t.featured ? "text-white" : "text-ink-950")}>{t.name}</span>
                    <span className={cn("block text-xs", t.featured ? "text-white/60" : "text-ink-500")}>{t.role}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}

          {/* Trust card */}
          <Reveal delay={220}>
            <div className="flex h-full flex-col justify-center rounded-3xl border border-dashed border-ink-300 bg-ink-50/60 p-7 text-center sm:p-9">
              <p className="text-4xl font-semibold tracking-tight text-ink-950">
                <span className="text-gradient">4.9</span>
                <span className="text-xl text-ink-400">/5</span>
              </p>
              <p className="mt-2 text-sm text-ink-600">average rating from volunteer surveys</p>
              <a
                href="#join"
                className="mt-5 inline-flex items-center justify-center gap-1.5 text-sm font-semibold text-brand-700 transition hover:gap-2.5"
              >
                Add your voice <span aria-hidden>→</span>
              </a>
            </div>
          </Reveal>
        </div>
        <p className="mt-6 text-center text-xs text-ink-400">Testimonials shown are illustrative samples for this preview.</p>
      </div>
    </section>
  );
}
