import { useId, useState, type CSSProperties } from "react";
import { Check, Landmark, Store, Users, type LucideIcon } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { useAnimatedNumber } from "@/hooks/useAnimatedNumber";

const benefits: { icon: LucideIcon; who: string; title: string; points: string[] }[] = [
  {
    icon: Users,
    who: "For citizens",
    title: "Your receipt has real power",
    points: [
      "See exactly how much tax was charged on your bill",
      "Report in one tap — fully anonymous",
      "Get an update on every case you help start",
    ],
  },
  {
    icon: Store,
    who: "For honest businesses",
    title: "Compete on a level playing field",
    points: [
      "Stop being undercut by brands that skip tax",
      "Earn a public Verified Compliant badge",
      "Use our free invoice self-check tool",
    ],
  },
  {
    icon: Landmark,
    who: "For Pakistan",
    title: "More revenue, no new taxes",
    points: [
      "Recover tax already collected from consumers",
      "Fund schools, clinics and roads we all use",
      "Open, anonymised data for reporters & researchers",
    ],
  },
];

/** 1.5 crore = Rs 15,000,000. Pakistani numbering reads better locally. */
function formatPkr(n: number) {
  if (n >= 1e7) return { num: (n / 1e7).toFixed(2), unit: "crore" };
  if (n >= 1e5) return { num: (n / 1e5).toFixed(2), unit: "lakh" };
  return { num: Math.round(n).toLocaleString("en-US"), unit: "" };
}

const rs = (n: number) => `Rs ${Math.round(n).toLocaleString("en-US")}`;

function Calculator() {
  const billId = useId();
  const volId = useId();
  const [bill, setBill] = useState(5000);
  const [perDay, setPerDay] = useState(100);

  const taxPerBill = (bill * 18) / 118; // GST portion of a tax-inclusive bill
  const perDayTax = taxPerBill * perDay;
  const perYear = perDayTax * 365;
  const animatedYear = useAnimatedNumber(perYear);
  const animatedDay = useAnimatedNumber(perDayTax);
  const animatedMonth = useAnimatedNumber(perDayTax * 30);
  const animatedBill = useAnimatedNumber(taxPerBill);
  const big = formatPkr(animatedYear);

  return (
    <div className="glass-dark conic-border relative overflow-hidden rounded-[2rem] p-6 sm:p-10">
      <div aria-hidden className="absolute -right-24 -top-24 size-72 rounded-full bg-brand-500/25 blur-3xl" />
      <div className="relative grid gap-10 lg:grid-cols-[1fr_1.05fr] lg:gap-14">
        {/* Inputs */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-brand-200">Tax-at-stake calculator</p>
          <h3 className="mt-3 text-balance text-2xl font-semibold !text-white sm:text-3xl">
            See what a single outlet can add up to
          </h3>
          <p className="mt-3 text-sm leading-relaxed text-white/60">
            Move the sliders. If the 18% GST collected on each bill is never deposited, this is what quietly slips away.
          </p>

          <div className="mt-8 space-y-8">
            <div>
              <div className="mb-3 flex items-baseline justify-between">
                <label htmlFor={billId} className="text-sm font-medium text-white/90">
                  Average bill (incl. GST)
                </label>
                <output htmlFor={billId} className="font-mono text-sm font-medium text-brand-200">
                  {rs(bill)}
                </output>
              </div>
              <input
                id={billId}
                type="range"
                className="range"
                min={500}
                max={50000}
                step={500}
                value={bill}
                onChange={(e) => setBill(Number(e.target.value))}
                style={{ "--fill": `${((bill - 500) / (50000 - 500)) * 100}%` } as CSSProperties}
                aria-valuetext={rs(bill)}
              />
              <div className="mt-2 flex justify-between text-[0.7rem] text-white/40">
                <span>Rs 500</span>
                <span>Rs 50,000</span>
              </div>
            </div>

            <div>
              <div className="mb-3 flex items-baseline justify-between">
                <label htmlFor={volId} className="text-sm font-medium text-white/90">
                  Bills issued per day
                </label>
                <output htmlFor={volId} className="font-mono text-sm font-medium text-brand-200">
                  {perDay.toLocaleString("en-US")}
                </output>
              </div>
              <input
                id={volId}
                type="range"
                className="range"
                min={5}
                max={500}
                step={5}
                value={perDay}
                onChange={(e) => setPerDay(Number(e.target.value))}
                style={{ "--fill": `${((perDay - 5) / (500 - 5)) * 100}%` } as CSSProperties}
                aria-valuetext={`${perDay} bills per day`}
              />
              <div className="mt-2 flex justify-between text-[0.7rem] text-white/40">
                <span>5</span>
                <span>500</span>
              </div>
            </div>
          </div>
        </div>

        {/* Output */}
        <div className="flex flex-col justify-between rounded-3xl bg-black/25 p-6 ring-1 ring-inset ring-white/10 sm:p-8">
          <div role="status">
            <p className="text-sm font-medium text-white/60">Tax potentially undeposited in one year</p>
            <p className="mt-3 flex flex-wrap items-baseline gap-x-3 text-white">
              <span className="text-lg font-medium text-white/50">Rs</span>
              <span className="text-gradient-light text-6xl font-semibold tracking-tight tabular-nums sm:text-7xl">
                {big.num}
              </span>
              {big.unit && <span className="font-serif text-3xl italic text-gold-300 sm:text-4xl">{big.unit}</span>}
            </p>
            <p className="sr-only">
              With an average bill of {rs(bill)} and {perDay} bills per day, about {rs(perYear)} of GST is collected per
              year.
            </p>
          </div>

          <dl className="mt-8 grid grid-cols-3 gap-3 text-center">
            {[
              { l: "Per bill", v: animatedBill },
              { l: "Per day", v: animatedDay },
              { l: "Per month", v: animatedMonth },
            ].map((x) => (
              <div key={x.l} className="rounded-2xl bg-white/5 px-2 py-3.5 ring-1 ring-inset ring-white/10">
                <dt className="text-[0.7rem] text-white/50">{x.l}</dt>
                <dd className="mt-1 text-sm font-semibold tabular-nums text-white sm:text-base">{rs(x.v)}</dd>
              </div>
            ))}
          </dl>

          <p className="mt-6 text-[0.72rem] leading-relaxed text-white/40">
            Illustrative estimate assuming the 18% standard GST rate is included in the bill and 365 trading days. Real
            outcomes depend on each case.
          </p>
        </div>
      </div>
    </div>
  );
}

export function Benefits() {
  return (
    <section id="benefits" aria-labelledby="benefits-title" className="px-3 py-6 sm:px-6 sm:py-10">
      <div className="relative isolate mx-auto max-w-[92rem] overflow-hidden rounded-[2rem] bg-ink-950 sm:rounded-[3rem]">
        {/* Backdrop */}
        <div aria-hidden className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-[radial-gradient(60%_50%_at_15%_0%,rgb(20_128_84/0.45),transparent),radial-gradient(50%_45%_at_100%_100%,rgb(226_167_43/0.18),transparent)]" />
          <div className="bg-grid-light mask-fade-radial absolute inset-0" />
          <div className="absolute -left-24 top-1/3 size-96 animate-drift rounded-full bg-brand-500/15 blur-3xl" />
        </div>

        <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
          <SectionHeading
            id="benefits-title"
            dark
            eyebrow="Why it matters"
            title={
              <>
                A fairer Pakistan starts at the <Accent light>checkout counter</Accent>
              </>
            }
            description="When one brand skips tax, every honest competitor is undercut and every citizen carries the difference. Here’s what changes when receipts become evidence."
          />

          <div className="mt-14 grid gap-5 sm:mt-20 lg:grid-cols-3">
            {benefits.map((b, i) => (
              <Reveal key={b.who} delay={i * 110}>
                <article className="glass-dark group h-full rounded-3xl p-7 transition-all duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1.5 hover:bg-white/8 sm:p-8">
                  <span className="grid size-12 place-items-center rounded-2xl bg-brand-500/15 text-brand-200 ring-1 ring-inset ring-brand-300/25 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6">
                    <b.icon className="size-5.5" aria-hidden />
                  </span>
                  <p className="mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-brand-200">{b.who}</p>
                  <h3 className="mt-2 text-xl font-semibold !text-white">{b.title}</h3>
                  <ul className="mt-5 space-y-3">
                    {b.points.map((p) => (
                      <li key={p} className="flex gap-3 text-[0.93rem] leading-snug text-white/70">
                        <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-brand-500/25 text-brand-200">
                          <Check className="size-3" strokeWidth={3} aria-hidden />
                        </span>
                        {p}
                      </li>
                    ))}
                  </ul>
                </article>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-6" dir="scale">
            <Calculator />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
