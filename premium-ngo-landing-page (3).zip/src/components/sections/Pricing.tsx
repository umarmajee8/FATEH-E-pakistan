import { useState } from "react";
import { Check, Heart } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { useAnimatedNumber } from "@/hooks/useAnimatedNumber";
import { cn } from "@/utils/cn";

const plans = [
  {
    id: "citizen",
    name: "Citizen",
    tagline: "For every shopper who wants a fairer market.",
    price: 0,
    yearly: 0,
    cta: "Start reporting",
    variant: "secondary" as const,
    features: [
      "Unlimited receipt scans & reports",
      "100% anonymous submissions",
      "Live status on every case you start",
      "Community forum & monthly briefings",
    ],
  },
  {
    id: "watchdog",
    name: "Watchdog",
    tagline: "Fund the verification and legal work that makes cases stick.",
    price: 1500,
    yearly: 1200,
    cta: "Become a Watchdog",
    variant: "light" as const,
    popular: true,
    features: [
      "Everything in Citizen",
      "Priority review for your reports",
      "Early access to the Brand Risk Index",
      "Monthly impact report on your contribution",
      "Watchdog badge & volunteer training",
    ],
  },
  {
    id: "partner",
    name: "Partner",
    tagline: "For law firms, newsrooms, CA firms and CSR programmes.",
    price: null,
    yearly: null,
    cta: "Talk to our team",
    variant: "dark" as const,
    features: [
      "Everything in Watchdog",
      "Anonymised data & API access",
      "Dedicated case manager",
      "Joint investigations & custom reports",
      "Co-branded compliance campaigns",
    ],
  },
];

function Price({ amount }: { amount: number | null }) {
  const v = useAnimatedNumber(amount ?? 0, 500);
  if (amount === null) return <span className="text-4xl font-semibold tracking-tight sm:text-5xl">Custom</span>;
  if (amount === 0) return <span className="text-5xl font-semibold tracking-tight">Free</span>;
  return (
    <span className="flex items-baseline gap-1.5">
      <span className="text-base font-medium opacity-60">Rs</span>
      <span className="text-5xl font-semibold tabular-nums tracking-tight">{Math.round(v).toLocaleString("en-US")}</span>
      <span className="text-sm font-medium opacity-60">/ month</span>
    </span>
  );
}

export function Pricing() {
  const [yearly, setYearly] = useState(false);

  return (
    <section id="pricing" aria-labelledby="pricing-title" className="relative py-20 sm:py-28">
      <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-ink-50/80 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="pricing-title"
          eyebrow="Membership"
          title={
            <>
              Reporting is free. <Accent>Impact</Accent> scales with you.
            </>
          }
          description="Citizens never pay a rupee. Optional memberships fund verification, legal filings and volunteer safety."
        />

        {/* Billing switch */}
        <Reveal delay={120} className="mt-10 flex items-center justify-center gap-4">
          <span className={cn("text-sm font-medium transition-colors", !yearly ? "text-ink-950" : "text-ink-500")}>Monthly</span>
          <button
            type="button"
            role="switch"
            aria-checked={yearly}
            aria-label="Bill yearly and save 20 percent"
            onClick={() => setYearly((v) => !v)}
            className={cn(
              "relative h-8 w-14 rounded-full p-1 ring-1 ring-inset transition-colors duration-500",
              yearly ? "bg-brand-600 ring-brand-700" : "bg-ink-200 ring-ink-300"
            )}
          >
            <span
              className={cn(
                "block size-6 rounded-full bg-white shadow-md transition-transform duration-500 ease-[var(--ease-out-expo)]",
                yearly ? "translate-x-6" : "translate-x-0"
              )}
            />
          </button>
          <span className={cn("flex items-center gap-2 text-sm font-medium transition-colors", yearly ? "text-ink-950" : "text-ink-500")}>
            Yearly
            <span className="rounded-full bg-gold-300/40 px-2 py-0.5 text-[0.68rem] font-bold uppercase tracking-wider text-gold-500 ring-1 ring-inset ring-gold-300">
              Save 20%
            </span>
          </span>
        </Reveal>

        <div className="mx-auto mt-12 grid max-w-md gap-6 sm:mt-14 lg:max-w-none lg:grid-cols-3 lg:items-stretch lg:gap-7">
          {plans.map((p, i) => (
            <Reveal key={p.id} delay={i * 120} className={cn(p.popular && "lg:-my-4")}>
              <article
                className={cn(
                  "relative flex h-full flex-col rounded-[2rem] p-7 transition-all duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1.5 sm:p-9",
                  p.popular
                    ? "conic-border bg-gradient-to-b from-brand-900 to-ink-950 text-white shadow-[0_50px_90px_-35px_rgb(6_38_27/0.85)]"
                    : "border border-ink-200/70 bg-white shadow-card hover:shadow-lift"
                )}
              >
                {p.popular && (
                  <>
                    <div aria-hidden className="absolute -top-20 left-1/2 size-56 -translate-x-1/2 rounded-full bg-brand-400/30 blur-3xl" />
                    <span className="absolute right-6 top-6 inline-flex items-center gap-1.5 rounded-full bg-gold-300 px-3 py-1 text-[0.68rem] font-bold uppercase tracking-wider text-ink-950">
                      <Heart className="size-3 fill-current" aria-hidden /> Most popular
                    </span>
                  </>
                )}

                <div className="relative">
                  <h3 className={cn("text-lg font-semibold", p.popular && "!text-white")}>{p.name}</h3>
                  <p className={cn("mt-1.5 min-h-[2.75rem] text-sm leading-snug", p.popular ? "text-white/60" : "text-ink-500")}>
                    {p.tagline}
                  </p>

                  <div className={cn("mt-6 flex h-14 items-center", p.popular ? "text-white" : "text-ink-950")}>
                    <Price amount={p.price === null ? null : yearly ? p.yearly : p.price} />
                  </div>
                  <p className={cn("mt-1 h-5 text-xs", p.popular ? "text-white/50" : "text-ink-400")}>
                    {p.price
                      ? yearly
                        ? `Billed yearly — Rs ${((p.yearly ?? 0) * 12).toLocaleString("en-US")}`
                        : "Billed monthly · cancel anytime"
                      : p.price === 0
                        ? "Free forever — no card needed"
                        : "Tailored to your organisation"}
                  </p>

                  <Button
                    href="#join"
                    variant={p.variant}
                    size="lg"
                    arrow
                    className="mt-7 w-full"
                    aria-label={`${p.cta} — ${p.name} plan`}
                  >
                    {p.cta}
                  </Button>

                  <div className={cn("my-7 h-px", p.popular ? "bg-white/10" : "bg-ink-100")} />

                  <ul className="space-y-3.5">
                    {p.features.map((f) => (
                      <li key={f} className={cn("flex gap-3 text-[0.92rem] leading-snug", p.popular ? "text-white/80" : "text-ink-700")}>
                        <span
                          className={cn(
                            "mt-px grid size-5 shrink-0 place-items-center rounded-full",
                            p.popular ? "bg-brand-400/25 text-brand-200" : "bg-brand-50 text-brand-700"
                          )}
                        >
                          <Check className="size-3" strokeWidth={3} aria-hidden />
                        </span>
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mx-auto mt-12 max-w-2xl text-center text-sm leading-relaxed text-ink-500">
            Pay securely with JazzCash, Easypaisa, bank transfer or card. Every contribution is spent on verification,
            legal filings and volunteer safety — and our accounts are published each year.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
