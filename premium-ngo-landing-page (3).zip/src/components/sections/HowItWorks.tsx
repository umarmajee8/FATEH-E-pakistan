import { Gavel, ScanLine, ShieldCheck, type LucideIcon } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { useInView } from "@/hooks/useInView";
import { cn } from "@/utils/cn";

const steps: { n: string; icon: LucideIcon; title: string; body: string; chips: string[] }[] = [
  {
    n: "01",
    icon: ScanLine,
    title: "Snap the bill",
    body: "Any receipt where sales tax is charged — restaurants, retail, electronics, clinics. Our scanner reads the shop, NTN, GST line and invoice details right on your phone.",
    chips: ["Urdu & English receipts", "Works on poor light"],
  },
  {
    n: "02",
    icon: ShieldCheck,
    title: "We verify the invoice",
    body: "The FBR invoice number and QR code are checked, then cross-matched with reports from other citizens at the same outlet. Two human reviewers confirm every flag.",
    chips: ["Double-verified", "Pattern matching"],
  },
  {
    n: "03",
    icon: Gavel,
    title: "We take it forward",
    body: "Verified evidence bundles are reviewed by our pro-bono legal desk and submitted to the relevant authorities. You get a status update at every milestone.",
    chips: ["Pro-bono lawyers", "Live case tracking"],
  },
];

export function HowItWorks() {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.3 });

  return (
    <section id="how-it-works" aria-labelledby="how-title" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="how-title"
          eyebrow="How it works"
          title={
            <>
              From a crumpled receipt to a <Accent>case file</Accent> in three steps
            </>
          }
          description="No paperwork, no confrontation, no risk. Just your phone and thirty seconds."
        />

        <div ref={ref} className="relative mt-16 sm:mt-20">
          {/* Connector line (desktop) */}
          <div aria-hidden className="absolute left-[16.66%] right-[16.66%] top-[calc(3.75rem-1px)] hidden h-0.5 rounded-full bg-ink-200 lg:block">
            <div
              className={cn(
                "h-full origin-left bg-gradient-to-r from-brand-500 via-brand-300 to-gold-400 transition-transform duration-[1800ms] ease-[var(--ease-out-expo)]",
                inView ? "scale-x-100" : "scale-x-0"
              )}
            />
          </div>

          <ol className="grid gap-6 lg:grid-cols-3 lg:gap-8">
            {steps.map((s, i) => (
              <Reveal as="li" key={s.n} delay={i * 130} className="list-none">
                <SpotlightCard className="h-full p-7 sm:p-8">
                  <div className="flex items-start justify-between">
                    <div className="relative">
                      <span
                        aria-hidden
                        className={cn(
                          "absolute inset-0 rounded-2xl bg-brand-500/30 blur-xl transition-opacity duration-1000",
                          inView ? "opacity-100" : "opacity-0"
                        )}
                        style={{ transitionDelay: `${600 + i * 500}ms` }}
                      />
                      <span className="relative grid size-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-800 text-white shadow-lg shadow-brand-700/25 ring-1 ring-inset ring-white/25">
                        <s.icon className="size-6" aria-hidden />
                      </span>
                    </div>
                    <span className="font-mono text-sm font-medium text-ink-300" aria-hidden>
                      {s.n}
                    </span>
                  </div>
                  <h3 className="mt-7 text-xl font-semibold sm:text-2xl">
                    <span className="sr-only">Step {i + 1}: </span>
                    {s.title}
                  </h3>
                  <p className="mt-3 text-[0.95rem] leading-relaxed text-ink-600">{s.body}</p>
                  <ul className="mt-6 flex flex-wrap gap-2">
                    {s.chips.map((c) => (
                      <li
                        key={c}
                        className="rounded-full bg-ink-50 px-3 py-1 text-xs font-medium text-ink-600 ring-1 ring-inset ring-ink-200/80"
                      >
                        {c}
                      </li>
                    ))}
                  </ul>
                </SpotlightCard>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
