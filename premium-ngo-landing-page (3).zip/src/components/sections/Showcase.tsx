import { useRef, useState, type KeyboardEvent } from "react";
import { BarChart3, Check, ChevronRight, FolderOpen, Lock, ScanLine, ShieldCheck, type LucideIcon } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { Accent, SectionHeading } from "@/components/ui/SectionHeading";
import { cn } from "@/utils/cn";

const tabs: { id: string; icon: LucideIcon; label: string; title: string; body: string; url: string }[] = [
  {
    id: "scan",
    icon: ScanLine,
    label: "Scanner",
    title: "Capture in seconds",
    body: "Auto-detects the receipt, reads every tax field and checks the FBR invoice number on the spot — even on crumpled, faded or Urdu receipts.",
    url: "app.fateh-e-pakistan.org/scan",
  },
  {
    id: "risk",
    icon: BarChart3,
    label: "Risk Index",
    title: "Spot patterns at a glance",
    body: "Anonymised reports roll up into a live risk score for every outlet, sector and city — so reviewers focus where evidence is strongest.",
    url: "app.fateh-e-pakistan.org/risk-index",
  },
  {
    id: "case",
    icon: FolderOpen,
    label: "Case file",
    title: "Follow every case end-to-end",
    body: "From first scan to formal filing, each milestone is logged in a tamper-evident timeline that reporters and legal partners can trust.",
    url: "app.fateh-e-pakistan.org/cases/PK-2041",
  },
];

/* ------------------------------------------------------------------ */
/*  Panels                                                             */
/* ------------------------------------------------------------------ */
function ScanPanel() {
  const fields = [
    { k: "Shop name", v: "Sample Kitchen & Co.", c: "99%", ok: true },
    { k: "NTN", v: "••••••• - 3", c: "98%", ok: true },
    { k: "Date & time", v: "12 Mar · 8:42 PM", c: "97%", ok: true },
    { k: "GST charged", v: "Rs 1,800 (18%)", c: "99%", ok: true },
    { k: "FBR invoice no.", v: "Not found", c: "—", ok: false },
    { k: "Verification QR", v: "Missing", c: "—", ok: false },
  ];
  return (
    <div className="grid grid-cols-1 gap-5 p-5 sm:p-6 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <div className="relative rounded-2xl bg-ink-100/70 p-4">
        <div className="mx-auto max-w-[15rem] rotate-[-1deg] rounded-md bg-[#fbfaf5] p-4 font-mono text-[0.68rem] leading-relaxed text-ink-700 shadow-xl shadow-ink-900/10">
          <p className="relative mx-auto w-fit rounded border-2 border-dashed border-brand-500 px-1.5 text-center font-medium text-ink-950">
            SAMPLE KITCHEN &amp; CO.
          </p>
          <p className="mt-1 text-center text-ink-500">Gulberg III · Lahore</p>
          <div className="my-2 border-t border-dashed border-ink-300" />
          <p className="flex justify-between"><span>Family Karahi</span><span>4,800</span></p>
          <p className="flex justify-between"><span>BBQ Platter</span><span>3,600</span></p>
          <p className="flex justify-between"><span>Naan ×6</span><span>600</span></p>
          <p className="flex justify-between"><span>Cold drinks ×4</span><span>1,000</span></p>
          <div className="my-2 border-t border-dashed border-ink-300" />
          <p className="flex justify-between rounded border-2 border-dashed border-gold-500 bg-gold-300/30 px-1.5">
            <span>GST 18%</span><span className="font-medium">1,800</span>
          </p>
          <p className="mt-1 flex justify-between font-medium text-ink-950"><span>TOTAL</span><span>11,800</span></p>
          <p className="mt-2 flex justify-between rounded border-2 border-dashed border-rose-500 bg-rose-100/70 px-1.5 text-rose-700">
            <span>FBR INV #</span><span>— none —</span>
          </p>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold text-ink-950">Extracted fields</p>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-50 px-2.5 py-1 text-[0.7rem] font-bold uppercase tracking-wider text-rose-700 ring-1 ring-inset ring-rose-200">
            High risk
          </span>
        </div>
        <ul className="mt-3 divide-y divide-ink-100 rounded-2xl border border-ink-200/70 bg-white">
          {fields.map((f) => (
            <li key={f.k} className="flex items-center justify-between gap-3 px-4 py-2.5 text-sm">
              <span className="text-ink-500">{f.k}</span>
              <span className="flex items-center gap-2.5">
                <span className={cn("font-medium", f.ok ? "text-ink-900" : "text-rose-600")}>{f.v}</span>
                <span className="w-9 text-right font-mono text-[0.68rem] text-ink-400">{f.c}</span>
              </span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex items-center gap-3">
          <span className="inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-full bg-gradient-to-b from-brand-500 to-brand-700 text-sm font-semibold text-white shadow-glow">
            Send for review <ChevronRight className="size-4" aria-hidden />
          </span>
          <span className="inline-flex items-center gap-1.5 text-xs text-ink-500">
            <Lock className="size-3.5" aria-hidden /> Anonymous
          </span>
        </div>
      </div>
    </div>
  );
}

function RiskPanel() {
  const kpis = [
    { l: "Reports this week", v: "1,284", d: "▲ 12%" },
    { l: "High-risk outlets", v: "214", d: "▲ 4%" },
    { l: "Verified rate", v: "91%", d: "▲ 2%" },
  ];
  const rows = [
    { n: "Sample Kitchen & Co.", city: "Lahore", r: 42, s: 92, st: "Under review", tone: "gold" },
    { n: "Sample Gadget Hub", city: "Karachi", r: 37, s: 86, st: "Filed", tone: "brand" },
    { n: "Sample Threads", city: "Islamabad", r: 29, s: 74, st: "Under review", tone: "gold" },
    { n: "Sample Bakers", city: "Multan", r: 18, s: 58, st: "Monitoring", tone: "ink" },
    { n: "Sample Mobile Mart", city: "Peshawar", r: 15, s: 47, st: "Monitoring", tone: "ink" },
  ];
  const tones: Record<string, string> = {
    gold: "bg-gold-300/30 text-gold-500 ring-gold-300/70",
    brand: "bg-brand-50 text-brand-700 ring-brand-200",
    ink: "bg-ink-100 text-ink-600 ring-ink-200",
  };
  return (
    <div className="p-5 sm:p-6">
      <div className="grid grid-cols-3 gap-3">
        {kpis.map((k) => (
          <div key={k.l} className="rounded-2xl border border-ink-200/70 bg-white p-3.5 sm:p-4">
            <p className="text-[0.68rem] leading-tight text-ink-500 sm:text-xs">{k.l}</p>
            <p className="mt-1.5 text-xl font-semibold tracking-tight text-ink-950 sm:text-2xl">{k.v}</p>
            <p className="mt-0.5 text-[0.68rem] font-medium text-brand-600">{k.d}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl border border-ink-200/70 bg-white">
        <div className="grid grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_auto] items-center gap-3 border-b border-ink-100 bg-ink-50/70 px-4 py-2.5 text-[0.68rem] font-semibold uppercase tracking-wider text-ink-500 sm:grid-cols-[minmax(0,1.6fr)_minmax(0,0.8fr)_minmax(0,0.6fr)_minmax(0,1.2fr)_auto]">
          <span>Outlet (sample)</span>
          <span className="hidden sm:block">City</span>
          <span className="hidden sm:block">Reports</span>
          <span>Risk</span>
          <span className="text-right">Status</span>
        </div>
        {rows.map((r) => (
          <div
            key={r.n}
            className="grid grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_auto] items-center gap-3 border-b border-ink-100 px-4 py-3 text-sm transition-colors last:border-0 hover:bg-brand-50/50 sm:grid-cols-[minmax(0,1.6fr)_minmax(0,0.8fr)_minmax(0,0.6fr)_minmax(0,1.2fr)_auto]"
          >
            <span className="truncate font-medium text-ink-900">{r.n}</span>
            <span className="hidden text-ink-500 sm:block">{r.city}</span>
            <span className="hidden font-mono text-ink-600 sm:block">{r.r}</span>
            <span className="flex items-center gap-2">
              <span className="h-1.5 w-full max-w-[6rem] overflow-hidden rounded-full bg-ink-100">
                <span
                  className={cn(
                    "block h-full rounded-full",
                    r.s > 80 ? "bg-rose-500" : r.s > 60 ? "bg-gold-400" : "bg-brand-400"
                  )}
                  style={{ width: `${r.s}%` }}
                />
              </span>
              <span className="font-mono text-xs text-ink-600">{r.s}</span>
            </span>
            <span
              className={cn(
                "justify-self-end whitespace-nowrap rounded-full px-2.5 py-1 text-[0.68rem] font-semibold ring-1 ring-inset",
                tones[r.tone]
              )}
            >
              {r.st}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CasePanel({ active }: { active: boolean }) {
  const steps = [
    { t: "Receipt submitted", d: "Mon · 09:14", done: true },
    { t: "Automated FBR invoice check — no match", d: "Mon · 09:14", done: true },
    { t: "Reviewer 1 confirmed evidence", d: "Mon · 13:02", done: true },
    { t: "Reviewer 2 confirmed evidence", d: "Tue · 10:47", done: true },
    { t: "Legal desk preparing filing", d: "In progress", now: true },
    { t: "Submitted to the relevant authority", d: "Pending", done: false },
  ];
  return (
    <div className="grid grid-cols-1 gap-5 p-5 sm:p-6 md:grid-cols-[minmax(0,1.25fr)_minmax(0,0.75fr)]">
      <div className="rounded-2xl border border-ink-200/70 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-semibold text-ink-950">
            Case #PK-2041 <span className="font-normal text-ink-500">· Sample Kitchen &amp; Co.</span>
          </p>
          <span className="rounded-full bg-gold-300/30 px-2.5 py-1 text-[0.68rem] font-semibold text-gold-500 ring-1 ring-inset ring-gold-300/70">
            Legal review
          </span>
        </div>
        <ol className="relative mt-5 space-y-4 before:absolute before:bottom-2 before:left-[0.6875rem] before:top-2 before:w-px before:bg-ink-200">
          {steps.map((s, i) => (
            <li
              key={s.t}
              className="relative flex gap-3.5 transition-all duration-700 ease-[var(--ease-out-expo)]"
              style={{
                transitionDelay: active ? `${200 + i * 110}ms` : "0ms",
                opacity: active ? 1 : 0,
                transform: active ? "none" : "translateX(-12px)",
              }}
            >
              <span
                className={cn(
                  "relative z-10 grid size-6 shrink-0 place-items-center rounded-full ring-4 ring-white",
                  s.done ? "bg-brand-500 text-white" : s.now ? "bg-gold-400 text-white" : "bg-ink-200 text-ink-400"
                )}
              >
                {s.done ? (
                  <Check className="size-3.5" strokeWidth={3} aria-hidden />
                ) : s.now ? (
                  <span className="size-2 animate-pulse rounded-full bg-white" />
                ) : (
                  <span className="size-1.5 rounded-full bg-white" />
                )}
              </span>
              <div className="-mt-0.5">
                <p className={cn("text-sm font-medium", s.done || s.now ? "text-ink-900" : "text-ink-400")}>{s.t}</p>
                <p className="text-xs text-ink-500">{s.d}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>

      <div className="space-y-3">
        <div className="rounded-2xl border border-ink-200/70 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-ink-500">Evidence bundle</p>
          <ul className="mt-3 space-y-2 text-sm text-ink-700">
            <li className="flex justify-between"><span>Receipts</span><b className="text-ink-950">3</b></li>
            <li className="flex justify-between"><span>Photos</span><b className="text-ink-950">5</b></li>
            <li className="flex justify-between"><span>Independent reporters</span><b className="text-ink-950">4</b></li>
          </ul>
        </div>
        <div className="rounded-2xl border border-brand-200 bg-gradient-to-br from-brand-50 to-white p-4">
          <p className="flex items-center gap-1.5 text-xs font-semibold text-brand-800">
            <ShieldCheck className="size-4" aria-hidden /> Integrity sealed
          </p>
          <p className="mt-2 break-all font-mono text-[0.65rem] leading-relaxed text-ink-500">sha256: 9f2c…a71e4b08d3</p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Section                                                            */
/* ------------------------------------------------------------------ */
export function Showcase() {
  const [active, setActive] = useState(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    const last = tabs.length - 1;
    let next = active;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") next = active === last ? 0 : active + 1;
    else if (e.key === "ArrowLeft" || e.key === "ArrowUp") next = active === 0 ? last : active - 1;
    else if (e.key === "Home") next = 0;
    else if (e.key === "End") next = last;
    else return;
    e.preventDefault();
    setActive(next);
    refs.current[next]?.focus();
  };

  return (
    <section id="product" aria-labelledby="product-title" className="relative overflow-hidden py-20 sm:py-28">
      <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-brand-50/60 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="product-title"
          eyebrow="Product tour"
          title={
            <>
              One platform, from <Accent>scan to submission</Accent>
            </>
          }
          description="Designed with lawyers, accountants and everyday shoppers — simple enough for anyone, rigorous enough for the courtroom."
        />

        <div className="mt-14 grid grid-cols-1 items-start gap-8 sm:mt-20 lg:grid-cols-[minmax(0,0.78fr)_minmax(0,1.22fr)] lg:gap-12">
          {/* Tab list */}
          <Reveal dir="left">
            <div role="tablist" aria-label="Product features" onKeyDown={onKeyDown} className="flex flex-col gap-3">
              {tabs.map((t, i) => {
                const on = i === active;
                return (
                  <button
                    key={t.id}
                    ref={(el) => {
                      refs.current[i] = el;
                    }}
                    role="tab"
                    id={`tab-${t.id}`}
                    aria-selected={on}
                    aria-controls={`panel-${t.id}`}
                    tabIndex={on ? 0 : -1}
                    onClick={() => setActive(i)}
                    className={cn(
                      "group relative w-full overflow-hidden rounded-3xl border p-5 text-left transition-all duration-500 ease-[var(--ease-out-expo)] sm:p-6",
                      on
                        ? "border-ink-200/80 bg-white shadow-lift"
                        : "border-transparent bg-transparent hover:bg-white/70 hover:border-ink-200/60"
                    )}
                  >
                    <span
                      aria-hidden
                      className={cn(
                        "absolute inset-y-5 left-0 w-1 rounded-r-full bg-gradient-to-b from-brand-400 to-brand-600 transition-all duration-500",
                        on ? "opacity-100" : "scale-y-0 opacity-0"
                      )}
                    />
                    <span className="flex items-center gap-4">
                      <span
                        className={cn(
                          "grid size-11 shrink-0 place-items-center rounded-2xl transition-all duration-500",
                          on ? "bg-brand-500 text-white shadow-lg shadow-brand-500/30" : "bg-ink-100 text-ink-600 group-hover:bg-brand-50 group-hover:text-brand-700"
                        )}
                      >
                        <t.icon className="size-5" aria-hidden />
                      </span>
                      <span>
                        <span className="block text-xs font-semibold uppercase tracking-wider text-ink-400">{t.label}</span>
                        <span className={cn("block text-lg font-semibold tracking-tight transition-colors", on ? "text-ink-950" : "text-ink-600")}>
                          {t.title}
                        </span>
                      </span>
                    </span>
                    <span
                      className={cn(
                        "grid transition-[grid-template-rows,opacity] duration-500 ease-[var(--ease-out-expo)]",
                        on ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                      )}
                    >
                      <span className="overflow-hidden">
                        <span className="block pl-[3.75rem] pt-3 text-[0.92rem] leading-relaxed text-ink-600">{t.body}</span>
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>
          </Reveal>

          {/* App frame */}
          <Reveal dir="right" delay={120}>
            <div className="relative">
              <div aria-hidden className="absolute -inset-4 -z-10 rounded-[2.5rem] bg-gradient-to-br from-brand-300/40 via-transparent to-gold-300/40 blur-2xl" />
              <div className="overflow-hidden rounded-[1.75rem] border border-ink-200/80 bg-ink-50 shadow-lift">
                <div className="flex items-center gap-3 border-b border-ink-200/70 bg-white/80 px-4 py-3">
                  <div className="flex gap-1.5" aria-hidden>
                    <span className="size-3 rounded-full bg-rose-300" />
                    <span className="size-3 rounded-full bg-gold-300" />
                    <span className="size-3 rounded-full bg-brand-300" />
                  </div>
                  <div className="mx-auto flex h-7 min-w-0 max-w-sm flex-1 items-center justify-center gap-1.5 rounded-full bg-ink-100/80 px-3 font-mono text-[0.68rem] text-ink-500">
                    <Lock className="size-3 shrink-0" aria-hidden />
                    <span className="min-w-0 truncate transition-all duration-300">{tabs[active].url}</span>
                  </div>
                  <div className="hidden w-10 sm:block" aria-hidden />
                </div>

                <div className="grid grid-cols-[minmax(0,1fr)] [&>*]:col-start-1 [&>*]:row-start-1">
                  {tabs.map((t, i) => (
                    <div
                      key={t.id}
                      role="tabpanel"
                      id={`panel-${t.id}`}
                      aria-labelledby={`tab-${t.id}`}
                      tabIndex={0}
                      className={cn(
                        "transition-all duration-700 ease-[var(--ease-out-expo)]",
                        i === active ? "visible translate-y-0 opacity-100" : "invisible translate-y-4 opacity-0"
                      )}
                    >
                      {t.id === "scan" && <ScanPanel />}
                      {t.id === "risk" && <RiskPanel />}
                      {t.id === "case" && <CasePanel active={i === active} />}
                    </div>
                  ))}
                </div>
              </div>
              <p className="mt-4 text-center text-xs text-ink-400">Interface preview · all names and figures are sample data.</p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
