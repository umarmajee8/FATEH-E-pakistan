import { useRef, type CSSProperties, type PointerEvent, type ReactNode } from "react";
import { Lock, Play, ShieldCheck, Sparkles, TrendingDown } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Accent } from "@/components/ui/SectionHeading";
import { HeroPhone } from "./HeroPhone";
import { useReducedMotion } from "@/hooks/useReducedMotion";

const headline = ["When", "a", "brand", "pockets", "your", "sales", "tax,"];

const avatars = [
  { i: "AR", c: "from-brand-400 to-brand-700" },
  { i: "IQ", c: "from-gold-300 to-gold-500" },
  { i: "HS", c: "from-ink-500 to-ink-800" },
  { i: "SK", c: "from-rose-300 to-rose-500" },
  { i: "ZM", c: "from-sky-300 to-sky-600" },
];

export function Hero() {
  const reduced = useReducedMotion();
  const visualRef = useRef<HTMLDivElement>(null);

  const onPointerMove = (e: PointerEvent<HTMLElement>) => {
    if (reduced || e.pointerType === "touch" || !visualRef.current) return;
    const r = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width) * 2 - 1;
    const y = ((e.clientY - r.top) / r.height) * 2 - 1;
    visualRef.current.style.setProperty("--px", x.toFixed(3));
    visualRef.current.style.setProperty("--py", y.toFixed(3));
  };

  const onPointerLeave = () => {
    visualRef.current?.style.setProperty("--px", "0");
    visualRef.current?.style.setProperty("--py", "0");
  };

  return (
    <section
      id="top"
      aria-labelledby="hero-title"
      onPointerMove={onPointerMove}
      onPointerLeave={onPointerLeave}
      className="relative isolate overflow-hidden pb-20 pt-28 sm:pt-36 lg:pb-28 lg:pt-40"
    >
      {/* ---------- Ambient background ---------- */}
      <div aria-hidden className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(60%_50%_at_20%_0%,var(--color-brand-100),transparent),radial-gradient(45%_40%_at_100%_20%,rgb(243_212_136/0.35),transparent)]" />
        <div className="bg-grid mask-fade-radial absolute inset-0 opacity-80" />
        <div className="absolute -left-40 -top-40 size-[36rem] animate-drift rounded-full bg-brand-300/40 blur-3xl" />
        <div className="absolute -right-32 top-1/3 size-[28rem] animate-drift-slow rounded-full bg-gold-300/30 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 size-[26rem] animate-drift-slow rounded-full bg-brand-500/15 blur-3xl" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-paper" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 sm:px-8 lg:grid-cols-[1.08fr_0.92fr] lg:gap-10">
        {/* ---------- Copy ---------- */}
        <div className="text-center lg:text-left">
          <a
            href="#benefits"
            className="rise group inline-flex items-center gap-2.5 rounded-full bg-white/70 py-1.5 pl-2 pr-4 text-xs font-medium text-ink-700 shadow-sm ring-1 ring-inset ring-ink-200/80 backdrop-blur transition hover:bg-white hover:shadow-md sm:text-[0.8rem]"
          >
            <span className="relative flex size-5 items-center justify-center">
              <span className="absolute size-full animate-pulse-ring rounded-full bg-brand-500/60" />
              <span className="relative size-2 rounded-full bg-brand-500" />
            </span>
            Citizen-powered · Non-partisan · Evidence-first
            <span className="text-brand-600 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden>
              →
            </span>
          </a>

          <h1
            id="hero-title"
            className="mt-7 text-balance text-[2.6rem] font-semibold leading-[1.02] sm:text-6xl lg:text-[4.5rem]"
          >
            {headline.map((w, i) => (
              <span key={w + i}>
                <span className="rise inline-block" style={{ "--d": `${120 + i * 70}ms` } as CSSProperties}>
                  {w}
                </span>{" "}
              </span>
            ))}
            <span className="rise inline-block" style={{ "--d": `${120 + headline.length * 70}ms` } as CSSProperties}>
              <Accent>Pakistan loses.</Accent>
            </span>
          </h1>

          <p
            className="rise mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-ink-600 sm:text-lg lg:mx-0"
            style={{ "--d": "700ms" } as CSSProperties}
          >
            Fateh-e-Pakistan turns every receipt into evidence. Scan a bill, verify its FBR invoice in seconds, and help
            our legal desk take <strong className="font-semibold text-ink-900">verified cases of sales tax evasion</strong> to
            the authorities — safely and anonymously.
          </p>

          <div
            className="rise mt-9 flex flex-col items-stretch gap-3 sm:flex-row sm:justify-center lg:justify-start"
            style={{ "--d": "820ms" } as CSSProperties}
          >
            <Button href="#join" size="lg" arrow>
              Report a receipt — it’s free
            </Button>
            <Button href="#how-it-works" size="lg" variant="secondary">
              <span className="grid size-6 place-items-center rounded-full bg-brand-500/10 text-brand-700">
                <Play className="size-3 translate-x-px fill-current" aria-hidden />
              </span>
              See how it works
            </Button>
          </div>

          <div
            className="rise mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center lg:justify-start"
            style={{ "--d": "960ms" } as CSSProperties}
          >
            <div className="flex -space-x-2.5" aria-hidden>
              {avatars.map((a, idx) => (
                <span
                  key={a.i}
                  className={`grid size-9 place-items-center rounded-full bg-gradient-to-br ${a.c} text-[0.65rem] font-bold text-white ring-2 ring-paper transition-transform duration-300 hover:-translate-y-1`}
                  style={{ zIndex: avatars.length - idx }}
                >
                  {a.i}
                </span>
              ))}
            </div>
            <p className="text-sm leading-snug text-ink-600 sm:text-left">
              <strong className="font-semibold text-ink-950">1,940+ volunteers</strong>, lawyers &amp; chartered
              accountants
              <br className="hidden sm:block" /> already on the watch across 38 cities.
            </p>
          </div>

          <ul
            className="rise mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[0.8rem] font-medium text-ink-600 lg:justify-start"
            style={{ "--d": "1060ms" } as CSSProperties}
          >
            <li className="inline-flex items-center gap-1.5">
              <Lock className="size-3.5 text-brand-600" aria-hidden /> 100% anonymous
            </li>
            <li className="inline-flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 text-brand-600" aria-hidden /> Every case verified twice
            </li>
            <li className="inline-flex items-center gap-1.5">
              <Sparkles className="size-3.5 text-brand-600" aria-hidden /> No cost to citizens
            </li>
          </ul>
        </div>

        {/* ---------- Visual ---------- */}
        <div
          ref={visualRef}
          className="rise relative mx-auto w-full max-w-[30rem] [--px:0] [--py:0]"
          style={{ "--d": "500ms" } as CSSProperties}
        >
          <div
            className="transition-transform duration-500 ease-out will-change-transform"
            style={{
              transform:
                "perspective(1400px) rotateY(calc(var(--px) * 7deg)) rotateX(calc(var(--py) * -5deg))",
            }}
          >
            <HeroPhone />
          </div>

          {/* Floating glass cards */}
          <FloatCard className="left-0 top-4 sm:-left-10 lg:-left-6 xl:-left-14" px={-16} py={-10} delay="0s">
            <span className="grid size-9 place-items-center rounded-xl bg-brand-500 text-white shadow-md shadow-brand-500/30">
              <ShieldCheck className="size-4.5" aria-hidden />
            </span>
            <div>
              <p className="text-xs font-semibold text-ink-950">FBR check complete</p>
              <p className="text-[0.7rem] text-ink-500">Verified in 2.1 seconds</p>
            </div>
          </FloatCard>

          <FloatCard className="top-[46%] hidden sm:flex sm:-right-8 lg:-right-4 xl:-right-12" px={-24} py={14} delay="1.4s" slow>
            <div className="flex -space-x-2" aria-hidden>
              {avatars.slice(0, 3).map((a) => (
                <span
                  key={a.i}
                  className={`grid size-7 place-items-center rounded-full bg-gradient-to-br ${a.c} text-[0.55rem] font-bold text-white ring-2 ring-white`}
                >
                  {a.i}
                </span>
              ))}
            </div>
            <div>
              <p className="text-xs font-semibold text-ink-950">Case #PK-2041</p>
              <p className="text-[0.7rem] text-ink-500">Sent to legal desk</p>
            </div>
          </FloatCard>

          <FloatCard className="bottom-16 hidden sm:flex sm:-left-14 lg:-left-8 xl:-left-20" px={-10} py={-18} delay="0.7s" slow>
            <span className="grid size-9 place-items-center rounded-xl bg-rose-500 text-white shadow-md shadow-rose-500/30">
              <TrendingDown className="size-4.5" aria-hidden />
            </span>
            <div>
              <p className="text-[0.7rem] text-ink-500">Tax at risk on this bill</p>
              <p className="text-sm font-bold tracking-tight text-ink-950">Rs 1,800</p>
            </div>
          </FloatCard>
        </div>
      </div>
    </section>
  );
}

function FloatCard({
  children,
  className = "",
  px,
  py,
  delay,
  slow = false,
}: {
  children: ReactNode;
  className?: string;
  px: number;
  py: number;
  delay: string;
  slow?: boolean;
}) {
  return (
    <div
      aria-hidden
      className={`absolute z-20 ${className}`}
      style={{
        transform: `translate3d(calc(var(--px) * ${px}px), calc(var(--py) * ${py}px), 0)`,
        transition: "transform 0.5s ease-out",
      }}
    >
      <div
        className={`glass-strong flex items-center gap-3 rounded-2xl p-3 pr-5 ${slow ? "animate-float-slow" : "animate-float"}`}
        style={{ animationDelay: delay }}
      >
        {children}
      </div>
    </div>
  );
}
