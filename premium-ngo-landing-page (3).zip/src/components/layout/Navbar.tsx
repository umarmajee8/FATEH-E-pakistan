import { useEffect, useRef, useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { Button } from "@/components/ui/Button";
import { cn } from "@/utils/cn";

const links = [
  { href: "#how-it-works", label: "How it works" },
  { href: "#features", label: "Features" },
  { href: "#product", label: "Product" },
  { href: "#benefits", label: "Impact" },
  { href: "#pricing", label: "Membership" },
  { href: "#faq", label: "FAQ" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const progressRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  // Scroll state + progress bar
  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const y = window.scrollY;
      setScrolled(y > 12);
      const max = document.documentElement.scrollHeight - window.innerHeight;
      if (progressRef.current) {
        progressRef.current.style.transform = `scaleX(${max > 0 ? Math.min(y / max, 1) : 0})`;
      }
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  // Scroll-spy
  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(`#${entry.target.id}`);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    links.forEach(({ href }) => {
      const el = document.querySelector(href);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  // Escape closes the mobile menu; desktop resize resets it
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        menuButtonRef.current?.focus();
      }
    };
    const onResize = () => window.innerWidth >= 1024 && setOpen(false);
    window.addEventListener("keydown", onKey);
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onResize);
    };
  }, [open]);

  return (
    <>
      <div className="fixed inset-x-0 top-0 z-[60] h-[3px] bg-transparent" aria-hidden>
        <div
          ref={progressRef}
          className="h-full origin-left scale-x-0 bg-gradient-to-r from-brand-500 via-brand-300 to-gold-400 will-change-transform"
        />
      </div>

      <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-6 sm:pt-4">
        <nav
          aria-label="Primary"
          className={cn(
            "relative mx-auto flex h-16 max-w-7xl items-center justify-between rounded-full px-3 pl-4 transition-all duration-500 ease-[var(--ease-out-expo)] sm:pl-6",
            scrolled || open
              ? "glass shadow-lg shadow-ink-950/5"
              : "border border-transparent bg-transparent"
          )}
        >
          <a href="#top" className="rounded-xl" aria-label="Fateh-e-Pakistan — home">
            <Logo />
          </a>

          <ul className="hidden items-center gap-1 lg:flex">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  aria-current={active === l.href ? "true" : undefined}
                  className={cn(
                    "relative rounded-full px-3.5 py-2 text-sm font-medium transition-colors duration-300",
                    active === l.href ? "text-brand-800" : "text-ink-600 hover:text-ink-950"
                  )}
                >
                  <span
                    aria-hidden
                    className={cn(
                      "absolute inset-0 -z-10 rounded-full bg-brand-500/10 ring-1 ring-inset ring-brand-500/15 transition-all duration-300",
                      active === l.href ? "scale-100 opacity-100" : "scale-90 opacity-0"
                    )}
                  />
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <Button href="#join" size="md" arrow className="hidden sm:inline-flex">
              Report a receipt
            </Button>
            <button
              ref={menuButtonRef}
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-full text-ink-900 transition hover:bg-ink-900/5 active:scale-95 lg:hidden"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              onClick={() => setOpen((v) => !v)}
            >
              <span className="relative size-5">
                <Menu
                  className={cn("absolute inset-0 size-5 transition-all duration-300", open ? "rotate-90 scale-50 opacity-0" : "rotate-0 scale-100 opacity-100")}
                />
                <X
                  className={cn("absolute inset-0 size-5 transition-all duration-300", open ? "rotate-0 scale-100 opacity-100" : "-rotate-90 scale-50 opacity-0")}
                />
              </span>
            </button>
          </div>

          {/* Mobile panel */}
          <div
            id="mobile-menu"
            className={cn(
              "absolute inset-x-0 top-[calc(100%+0.5rem)] origin-top rounded-3xl border border-ink-200/70 bg-white p-3 shadow-2xl shadow-ink-950/15 transition-all duration-400 ease-[var(--ease-out-expo)] lg:hidden",
              open ? "visible translate-y-0 scale-100 opacity-100" : "invisible -translate-y-2 scale-95 opacity-0"
            )}
          >
            <ul className="flex flex-col">
              {links.map((l, i) => (
                <li
                  key={l.href}
                  className={cn("transition-all duration-500 ease-[var(--ease-out-expo)]", open ? "translate-x-0 opacity-100" : "-translate-x-3 opacity-0")}
                  style={{ transitionDelay: open ? `${80 + i * 45}ms` : "0ms" }}
                >
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex min-h-12 items-center justify-between rounded-2xl px-4 text-base font-medium transition-colors hover:bg-brand-500/8",
                      active === l.href ? "text-brand-800" : "text-ink-800"
                    )}
                  >
                    {l.label}
                    {active === l.href && <span className="size-1.5 rounded-full bg-brand-500" aria-hidden />}
                  </a>
                </li>
              ))}
            </ul>
            <div className="mt-2 p-1">
              <Button href="#join" size="lg" arrow className="w-full" onClick={() => setOpen(false)}>
                Report a receipt
              </Button>
            </div>
          </div>
        </nav>
      </header>
    </>
  );
}
