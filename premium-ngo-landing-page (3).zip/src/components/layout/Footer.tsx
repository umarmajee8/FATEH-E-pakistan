import { ArrowUp, Mail, MapPin } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { Reveal } from "@/components/ui/Reveal";
import { FacebookIcon, InstagramIcon, WhatsappIcon, XIcon, YoutubeIcon } from "@/components/ui/SocialIcons";

const columns = [
  {
    title: "Platform",
    links: [
      { label: "How it works", href: "#how-it-works" },
      { label: "Features", href: "#features" },
      { label: "Product tour", href: "#product" },
      { label: "Membership", href: "#pricing" },
    ],
  },
  {
    title: "Organisation",
    links: [
      { label: "Our impact", href: "#benefits" },
      { label: "Voices", href: "#voices" },
      { label: "Legal desk", href: "#features" },
      { label: "Volunteer", href: "#join" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Help centre", href: "#faq" },
      { label: "Whistleblower safety", href: "#faq" },
      { label: "Press kit", href: "mailto:press@fateh-e-pakistan.org" },
      { label: "Contact", href: "mailto:hello@fateh-e-pakistan.org" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy policy", href: "#top" },
      { label: "Terms of use", href: "#top" },
      { label: "Code of conduct", href: "#top" },
      { label: "Annual accounts", href: "#top" },
    ],
  },
];

const socials = [
  { label: "Fateh-e-Pakistan on X", icon: XIcon },
  { label: "Fateh-e-Pakistan on Facebook", icon: FacebookIcon },
  { label: "Fateh-e-Pakistan on Instagram", icon: InstagramIcon },
  { label: "Fateh-e-Pakistan on YouTube", icon: YoutubeIcon },
  { label: "Fateh-e-Pakistan tip line on WhatsApp", icon: WhatsappIcon },
];

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-ink-200/70 bg-paper">
      <div className="mx-auto max-w-7xl px-5 pt-16 sm:px-8 sm:pt-20">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <Reveal>
            <a href="#top" aria-label="Fateh-e-Pakistan — back to top" className="inline-block rounded-xl">
              <Logo />
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-ink-600">
              An independent, non-partisan citizens’ initiative that turns everyday receipts into verified evidence —
              so every rupee of tax collected reaches Pakistan.
            </p>
            <p lang="ur" dir="rtl" className="mt-4 w-fit font-urdu text-lg leading-[2] text-brand-700">
              ہر رسید، ایک ثبوت
            </p>
            <ul className="mt-5 flex gap-2">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href="#top"
                    aria-label={s.label}
                    className="grid size-10 place-items-center rounded-full bg-white text-ink-700 ring-1 ring-inset ring-ink-200 transition-all duration-300 hover:-translate-y-1 hover:bg-brand-600 hover:text-white hover:ring-brand-600 hover:shadow-lg hover:shadow-brand-600/25"
                  >
                    <s.icon className="size-4.5" />
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-4">
            {columns.map((c, i) => (
              <Reveal key={c.title} delay={i * 80}>
                <h2 className="text-sm font-semibold text-ink-950">{c.title}</h2>
                <ul className="mt-4 space-y-3">
                  {c.links.map((l) => (
                    <li key={l.label}>
                      <a
                        href={l.href}
                        className="group inline-flex items-center gap-1 text-sm text-ink-600 transition-colors hover:text-brand-700"
                      >
                        <span className="relative">
                          {l.label}
                          <span className="absolute -bottom-0.5 left-0 h-px w-full origin-left scale-x-0 bg-brand-500 transition-transform duration-300 group-hover:scale-x-100" />
                        </span>
                      </a>
                    </li>
                  ))}
                </ul>
              </Reveal>
            ))}
          </nav>
        </div>

        <div className="mt-14 grid gap-4 border-t border-ink-200/70 py-8 text-sm text-ink-500 sm:grid-cols-2 lg:grid-cols-3">
          <p className="inline-flex items-center gap-2">
            <Mail className="size-4 text-brand-600" aria-hidden />
            <a href="mailto:hello@fateh-e-pakistan.org" className="hover:text-brand-700">
              hello@fateh-e-pakistan.org
            </a>
          </p>
          <p className="inline-flex items-center gap-2">
            <MapPin className="size-4 text-brand-600" aria-hidden /> Islamabad · Lahore · Karachi
          </p>
          <p className="sm:col-span-2 lg:col-span-1 lg:text-right">Registered non-profit initiative · Made with care in Pakistan</p>
        </div>

        <div className="border-t border-ink-200/70 py-8">
          <p className="max-w-4xl text-xs leading-relaxed text-ink-400">
            Fateh-e-Pakistan is independent and is not affiliated with the Federal Board of Revenue, any government body or
            any political party. Reports and case files describe allegations until adjudicated by the competent authority.
            Statistics, outlet names, testimonials and interface screens on this page are illustrative samples for preview
            purposes.
          </p>
          <div className="mt-6 flex flex-col-reverse items-start justify-between gap-4 sm:flex-row sm:items-center">
            <p className="text-xs text-ink-500">© {new Date().getFullYear()} Fateh-e-Pakistan. All rights reserved.</p>
            <a
              href="#top"
              className="group inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold text-ink-700 ring-1 ring-inset ring-ink-200 transition hover:bg-white hover:text-ink-950 hover:ring-ink-300"
            >
              Back to top
              <ArrowUp className="size-3.5 transition-transform duration-300 group-hover:-translate-y-0.5" aria-hidden />
            </a>
          </div>
        </div>
      </div>

      {/* Giant wordmark */}
      <div aria-hidden className="pointer-events-none select-none overflow-hidden px-4 pb-2 text-center">
        <p
          className="whitespace-nowrap bg-gradient-to-b from-ink-200 to-transparent bg-clip-text pb-[0.08em] font-semibold leading-[0.85] tracking-[-0.055em] text-transparent"
          style={{ fontSize: "clamp(2rem, 9.6vw, 10.5rem)" }}
        >
          Fateh-e-Pakistan
        </p>
      </div>
    </footer>
  );
}
