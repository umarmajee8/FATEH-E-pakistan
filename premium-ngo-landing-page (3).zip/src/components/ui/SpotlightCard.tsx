import type { HTMLAttributes, MouseEvent } from "react";
import { cn } from "@/utils/cn";

/** Card with a soft light + border glow that tracks the pointer. */
export function SpotlightCard({ className, onMouseMove, children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty("--mx", `${e.clientX - rect.left}px`);
    e.currentTarget.style.setProperty("--my", `${e.clientY - rect.top}px`);
    onMouseMove?.(e);
  };

  return (
    <div
      onMouseMove={handleMove}
      className={cn(
        "spotlight rounded-3xl border border-ink-200/70 bg-white shadow-card transition-[transform,box-shadow] duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1 hover:shadow-lift",
        className
      )}
      {...rest}
    >
      {children}
    </div>
  );
}
