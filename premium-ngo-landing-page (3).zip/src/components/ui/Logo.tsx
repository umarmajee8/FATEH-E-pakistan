import { cn } from "@/utils/cn";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-9 shrink-0", className)} aria-hidden fill="none">
      <defs>
        <linearGradient id="lm-bg" x1="4" y1="2" x2="28" y2="30" gradientUnits="userSpaceOnUse">
          <stop stopColor="#2fb27a" />
          <stop offset="1" stopColor="#0d4230" />
        </linearGradient>
        <mask id="lm-crescent" maskUnits="userSpaceOnUse" x="0" y="0" width="32" height="32">
          <rect width="32" height="32" fill="white" />
          <circle cx="17.2" cy="15" r="4.1" fill="black" />
        </mask>
      </defs>
      <rect width="32" height="32" rx="10" fill="url(#lm-bg)" />
      <rect x="0.5" y="0.5" width="31" height="31" rx="9.5" stroke="white" strokeOpacity="0.25" />
      <path
        d="M16 5.5 7.5 8.8v7.1c0 5.2 3.5 8.7 8.5 10.6 5-1.9 8.5-5.4 8.5-10.6V8.8z"
        stroke="white"
        strokeOpacity="0.95"
        strokeWidth="1.6"
        strokeLinejoin="round"
        fill="white"
        fillOpacity="0.08"
      />
      <circle cx="15" cy="16" r="5" fill="#f3d488" mask="url(#lm-crescent)" />
      <polygon
        fill="#f3d488"
        points="18.7,12.9 19.11,14.03 20.32,14.08 19.37,14.82 19.7,15.98 18.7,15.3 17.7,15.98 18.03,14.82 17.08,14.08 18.29,14.03"
      />
    </svg>
  );
}

export function Logo({ dark = false, className }: { dark?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark />
      <span className="flex flex-col leading-none">
        <span className={cn("text-[1.05rem] font-bold tracking-tight", dark ? "text-white" : "text-ink-950")}>
          Fateh<span className={dark ? "text-brand-300" : "text-brand-600"}>-e-</span>Pakistan
        </span>
        <span
          lang="ur"
          dir="rtl"
          className={cn("mt-1.5 self-start font-urdu text-[0.72rem] leading-none", dark ? "text-white/60" : "text-ink-500")}
        >
          فتحِ پاکستان
        </span>
      </span>
    </span>
  );
}
