import { useEffect, useState } from "react";
import { useReducedMotion } from "./useReducedMotion";

/** Animates a number from 0 → target once `start` becomes true. */
export function useCountUp(target: number, start: boolean, duration = 1800) {
  const reduced = useReducedMotion();
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!start) return;
    if (reduced) {
      setValue(target);
      return;
    }

    let raf = 0;
    const t0 = performance.now();
    const easeOutExpo = (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));

    const tick = (now: number) => {
      const progress = Math.min((now - t0) / duration, 1);
      setValue(target * easeOutExpo(progress));
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [start, target, duration, reduced]);

  return value;
}
